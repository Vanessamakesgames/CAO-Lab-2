Concurrency in Action:
Read -
3.1.1
3.1.2
3.2
3.2.1

Lab 2 Questions/Tasks:
- Change system to a multithreaded solution, allowing multiple sales to be processed at the same time
- Run the program multiple times and observe:
	- Do any issues emerge?
	- Does the seat availability chart match with the completed orders?
	- Are there any allocation issues?
		- Will everyone who was sold tickets be happy?
	- Take a screenshot of the output whenever there is a problem, and write a clear description of the problem
- For each problem identified:
	- What do you think was the cause of this problem? Provide detail beyond "threads did it". How did they cause the problem?
	- You're going to keep all 6 sales people, and customers are going to be still served in parallel, but small changes
	  to the process can be made. What changes would you make to solve each problem? Think about this in plain english in terms
	  if how you'd handle the problem of several people selling from the same pool of products.
	- Referring to chapter 3 of Concurrency in Action:
		- What parallel programming features does C++ offer that helps in "race condition" problems?
			- How do they help? (In my own words, short quotes allowed)
	- Write some pseudo code

- What parallel programming features does C++ offer that helps in "race condition" problems?
		- How do they help? (In my own words, short quotes allowed)
One feature I used was mutexes, which gives the current owner of the mutex the ability to lock out other potential users until it has completed its business. This helped to make sure that
mutexes didn't have the ability to sell the same seat multiple times by making sure that each thread only had access to sell the seats one at a time.

Problems:
1- After selling tickets, trying to rejoin threads would cause an error because some threads in vector where already rejoined and unuseable.
   Fixed by add if statement checking whether the threads where rejoinable and then rejoining.
2- Forgot to add mutex to sales function after adding threads.
   Fixed by adding lock() to start of function and unlock() before return.
3- Used i < cashiers.size() in the for loop for deleting the used threads which meant the for loop iterated only 3 times due to the 
   decreasing size.
   Fixed by changing value to a 6.
4- Multiple threads were accessing the same protected data and the mutex was being unlocked by a thread which shouldn't have had access.
5- Multiple threads were all accessing the same data and selling the same tickets.
6- When printing the successful order, the order which changed is getting an extra G printed
7- Cust6 is printing an extra "unavailable D:" because it wants two seats. Fixed by adding a check after the first unavailable ticket in
   multi-ticket orders.
8- Cashiers were still checking if customers wanted to change seats even when there were no seats left.
9- Printing two customers names without finishing what that customer was saying. I fixed this by using orderLock in the seatChange function.

Iterations:
1- I added threads to the original code and experienced problems 1 and 2.
2- I added a for loop to remove each of the used threads from the cashiers. This allowed me to remove the if statement to check if the thread
   was rejoinable. Experienced problem 3
3- Added a function to rejoin the threads and another function to remove the used threads from cashiers.
4- Added a function to check for seat availability if a customers original seat is unavailable. Experienced problem 4.
5- Tried to change code so that threads are passed a workflow where they sell the seat if possible, and then if not look for a new seat.
   (main creates each thread -> thread checks for seat -> thread sells seat / finds new seat -> thread rejoins)
   This caused problem 5, which was possibly caused by passing a copy of seats instead of a reference to it. Changing the passed in value to
   a reference partially solved the problem and caused problem 6.
6- I fixed problem 6 by assigning temp to the order instead of trying to delete and then assign each value. I also experienced issue 7
   most likely because by the time customer 6 was able to get access to the functions all of the seats were unavailable. I also changed the
   code to print the customer name and colour each time they print to cout. I also changed the seat changing function to check if enough seats
   were available before checking if the customer wants to change.
7- I added more locks and unlocks to the first mutex, as the last few iterations felt bottlenecked by the threads waiting for the mutex. I 
   was able to get the customers to actually feel like they were racing for tickets again, rather than having the program feel as if it were 
   not multithreaded. Problem 9 popped up, but I was able to resolve that by using a second mutex.
   I also added a call to the printOrder function to print the customers new tickets when they change seats and slightly modified the function
   so it will print "new" when the seats have been changed. Also added customer rage and changed how the functions get random ints when needed.

