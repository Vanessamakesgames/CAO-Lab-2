struct Order
{
  std::string custName;
  std::string color;
  std::vector<std::string> seatIds;
  int hesitancy{ 0 };
  bool sold{ false };
};

struct Seat
{
  std::string id;
  bool available {true};
};
