#include <thread>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include "colornames.h"
#include "structures.h"
#include "chrono"
#include "time.h"
using namespace std;

vector<Order> ordersCompleted;
mutex outLock;
mutex orderLock;

void printCustName(Order& order); // print the customers name with the color of their order
bool checkSeatChange(Order& order); // check if customer wants to change seats
bool checkAvailability(Order& order, vector<Seat>& seats); // finds if there are enough seats available to sell to the customer
Order seatChange(Order& order, vector<Seat>& seats); // checks if there are seats the customer can change to, then if the customer wants to. this returns the customers new order.
bool sellSeats(Order& order, vector<Seat>& seats); // sells seats to the customer
void printOrder(Order& order, bool isItNew); // prints the customer/successful orders
void showSeats(vector<Seat>& seats); // shows the available and unavailable seats
void rejoinThreads(vector<thread>& p_Cashiers); // get rid of this and just put back into main
void removeUsed(vector<thread>& p_Cashiers); // get rid of this too
void workflow(Order& order, vector<Seat>& seats); // cashier sells seats if possible, then changes seats (if possible) if the original seats were unavailable
void secondChanceTickets(Order& order, vector<Seat>& seats); // second round of ticket sales to sell any remaining seats
void customerRage(Order& angryCustomer); // the angry customers that missed out


int main()
{
  srand(time(NULL));
  vector<thread> cashiers;

  auto orders = vector<Order>{
    { "Cust 1", on_red, {"G1", "G2"}, (rand() % 100 + 1)},
    { "Cust 2", on_blue, {"G1"}, (rand() % 100 + 1)},
    { "Cust 3", on_green, {"G4", "G5"}, (rand() % 100 + 1)},
    { "Cust 4", on_yellow,  {"G5"}, (rand() % 100 + 1)}, 
    { "Cust 5", on_magenta, {"G4"}, (rand() % 100 + 1)},
    { "Cust 6", on_cyan,  {"G3", "G4"}, (rand() % 100 + 1)}  
  };

  auto seats = vector<Seat>{
    { "G1", true },
    { "G2", true },
    { "G3", true },
    { "G4", true },
    { "G5", true },
  };

  showSeats(seats);

  cout << "\n" << "## Customers Enter and the races are on!" << "\n\n";
  for (auto& order : orders)
  {
    cashiers.push_back(thread(workflow, ref(order), ref(seats))); // Starts selling tickets to the customers
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);

  vector<Seat> availSeats; // gets remaining available seats

  for (auto& seat : seats)
  {
    if (seat.available)
    {
      availSeats.push_back(seat);
    }
  }

  if (availSeats.size() >= 1)
  {
    cout << "\n## The movie is about to start! Last chance for tickets!\n\n";
    for (auto& order : orders)
    {
      if (!order.sold)cashiers.push_back(thread(secondChanceTickets, ref(order), ref(seats)));
    }
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);

  cout << "\n" << "## Successful Orders" << "\n\n";
  for (auto& order : ordersCompleted)
  {
    printOrder(order, false);
  }

  showSeats(seats);
  cout << "\n";

  vector<Order> angryCustomers; // stores orders of customers that were unable to get seats

  for (auto& order : orders)
  {
    if (!order.sold) angryCustomers.push_back(order);
  }

  for (auto& rage : angryCustomers)
  {
    cashiers.push_back(thread(customerRage, ref(rage)));
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);

  int temp = angryCustomers.size();
  for (int i = 0; i < temp; i++)
  {
    angryCustomers.pop_back();
  }
  
  temp = availSeats.size();
  for (int i = 0; i < temp; i++)
  {
    availSeats.pop_back();
  }
  
  cout << "\nBoss, we need more seats!\n";
}

void printCustName(Order& order)
{
  cout << white << order.color << order.custName << white << on_black;
}

bool checkSeatChange(Order& order)
{
  if (order.hesitancy >= 60)
  {
    cout << ": No thanks! My night is ruined now!\n";
    return false;
  }
  else if (order.hesitancy < 60 && order.hesitancy >= 40)
  {
    cout << ": Fine, I'll swap I guess...\n";
    return true;
  }
  else
  {
    cout << ": Awesome! I'll take any you can find!\n";
    return true;
  }
}

bool checkAvailability(Order& order, vector<Seat>& seats)
{
  int availSeats{ 0 };
  for (auto& seat : seats)
  {
    if (seat.available) availSeats++;
  }
  if (availSeats >= order.seatIds.size()) return true;
  return false;
}

Order seatChange(Order& order, vector<Seat>& seats)
{
  Order temp;
  temp.custName = order.custName;
  temp.color = order.color;
  temp.sold = order.sold;
  if (checkAvailability(order, seats))
  {
    orderLock.lock();
    printCustName(order);
    if (checkSeatChange(order))
    {
      for (auto& seat : seats)
      {
        if (seat.available)
        {
          temp.seatIds.push_back(seat.id);
          if (temp.seatIds.size() == order.seatIds.size()) break; // if seats in temp is equal to seats needed break out of loop
        }
      }
    }
    orderLock.unlock();
  }
  else
  {
    orderLock.lock();
    printCustName(order);
    cout << ": Not enough seats left! D:\n";
    orderLock.unlock();
  }

  return temp;
}

bool sellSeats(Order& order, vector<Seat>& seats)
{
  printCustName(order);
  // if the seats in the order aren't already sold, mark them sold and return true
  bool allAvailable{ true };

  for (auto& seatId : order.seatIds)
  {
    for (auto& seat : seats)
    {
      // If we find the seat and it's not available, order is ded.
      if (seat.id == seatId && !seat.available)
      {
        cout << ": unavailable D:\n";
        allAvailable = false;
        break;
      }
    }
    if (!allAvailable) break; // If customer wants two tickets and first seat is unavailable this exits the loop
  }
  if (allAvailable)
  {
    orderLock.lock();
    cout << ": Sold!\n";
    order.sold = true;
    ordersCompleted.push_back(order);

    for (auto& seatId : order.seatIds)
    {
      for (auto& seat : seats)
      {
        if (seat.id == seatId) seat.available = false;
      }
    }
    orderLock.unlock();
  }
  /*orderLock.unlock();*/
  return allAvailable;
}

void printOrder(Order& order, bool isItNew)
{
  printCustName(order);
  if (!isItNew) cout << ", seats: [";
  else cout << ", new seats: [";
  for (auto& seatId : order.seatIds)
  {
    cout << seatId << " ";
  }
  cout << "\b]\n";   // backspace removes the space after the last seat id
}

void showSeats(vector<Seat>& seats)
{
  cout << "\n" << "## Seat Availability" << "\n\n";
  int seatCount = seats.size();
  string line = "-";
  for (auto i = 0; i < seatCount; ++i)
  {
    line += "-----";
  }

  for (auto& seat : seats)
  {
    // If the seat is available, use green background, else red
    // if this syntax looks weird, google "universal initializers" and
    // "c++ ternary operator"
    string bg{ (seat.available) ? on_green : on_red };
    cout << "|" << white << bg << " " << seat.id << " " << white_on_black;
  }
  cout << "|" << endl;
}

void rejoinThreads(vector<thread>& p_Cashiers)
{
  for (thread& cashier : p_Cashiers)
  {
    if (cashier.joinable()) cashier.join();
  }
}

void removeUsed(vector<thread>& p_Cashiers)
{
  int temp = p_Cashiers.size();
  for (int i = 0; i < temp; i++)
  {
    p_Cashiers.pop_back();
  }
}

void workflow(Order& order, vector<Seat>& seats)
{
  this_thread::sleep_for(500ms);
  outLock.lock();
  printOrder(order, false);
  sellSeats(order, seats);
  outLock.unlock();
}

void secondChanceTickets(Order& order, vector<Seat>& seats)
{
  Order temp;
  outLock.lock();
  temp = seatChange(order, seats); // Need to find if any other seats are available + if customer wants to change seats
  if (order.seatIds.size() == temp.seatIds.size())
  {
    order = temp;
    printOrder(order, true);
    sellSeats(order, seats);
  }
  outLock.unlock();
}

void customerRage(Order& angryCustomer)
{
  outLock.lock();
  this_thread::sleep_for(500ms);

  printCustName(angryCustomer);
  if (angryCustomer.hesitancy >= 80)
  {
    cout << ": *throws a cashier through the popcorn machine*\n";
    outLock.unlock();
  }
  else if (angryCustomer.hesitancy >= 60 && angryCustomer.hesitancy < 80)
  {
    cout << ": That can't be! I demand to speak to your manager!\n";
    outLock.unlock();
  }
  else if (angryCustomer.hesitancy >= 40 && angryCustomer.hesitancy < 60)
  {
    cout << ": Well you've lost me as a customer! Good Day!\n";
    outLock.unlock();
  }
  else if (angryCustomer.hesitancy >= 20 && angryCustomer.hesitancy < 40)
  {
    cout << ": Arghhhhhh! But I have to see the new Marvel movie!\n";
    outLock.unlock();
  }
  else
  {
    cout << ": Damn, I'll go play video games instead\n";
    outLock.unlock();
  }
}