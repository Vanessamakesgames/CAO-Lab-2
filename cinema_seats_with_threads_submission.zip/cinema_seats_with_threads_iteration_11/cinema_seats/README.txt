Github link to earlier iterations + submission version: https://github.com/Vanessamakesgames/CAO-Lab-2

What went wrong?
-	I had issues knowing where to lock and unlock the mutexes to allow performance, but without the output becoming a garbled mess. This was an ongoing issue, as when I would change parts
	of the code the mutexes were behaving a little unpredictably in some iterations.
-	I tried to add a workflow for each thread where they would try to sell the tickets, then if they couldn't they would try to sell different seats. The issues I was mostly experiencing
	with this was that it made the program feel as if it were not multithreaded (a customer would say their seats, try to buy tickets, try to change seats, then try to buy tickets again),
	I was also having some difficulties randomising numbers for the check on whether the customer wants to change seats and their rage value if they cant get seats, and some issues with
	threads having access to the values at the same time and selling a single seat multiple times.

What went right?
-	Once I was able to get a better understanding of how the mutexes were affecting the program, I was able to more consistently make updates to the code without completely breaking
	everything.
-	Adding new functionality was very easy thanks to having a lot of the bones of the project already available in the original zip.
-	Debugging the program also wasn't too difficult, because I had an idea of what was breaking the code in the majority of cases that it broke.

Issues:
1 -	After selling tickets, trying to rejoin threads would cause an error because some threads in vector where already rejoined and unuseable.
   	Fixed by add if statement checking whether the threads where rejoinable and then rejoining.
2 - 	Forgot to add mutex to sales function after adding threads.
   	Fixed by adding lock() to start of function and unlock() before return.
3 - 	Used i < cashiers.size() in the for loop for deleting the used threads which meant the for loop iterated only 3 times due to the 
   	decreasing size.
   	Fixed by changing value to a 6.
4 - 	Multiple threads were accessing the same protected data and the mutex was being unlocked by a thread which shouldn't have had access.
5 - 	Multiple threads were all accessing the same data and selling the same tickets.
6 - 	When printing the successful order, the order which changed is getting an extra G printed
7 - 	Cust6 is printing an extra "unavailable D:" because it wants two seats. Fixed by adding a check after the first unavailable ticket in
   	multi-ticket orders.
8 - 	Cashiers were still checking if customers wanted to change seats even when there were no seats left.
9 - 	Printing two customers names without finishing what that customer was saying. I fixed this by using orderLock in the seatChange function.
10-	Occasionally some seats will be remaining if no customers want to change their seats, or if too few seats remain, meaning that sometimes only 3-4 seats are sold. 
	Moved srand to function which returns a random number, which seemed to give randomised results in debug.
11-	Forgot to add code to delete any second round buyers, so they appear as an angry customer. Resolved by using variable "orders" instead of "remOrders" in for loop on line 181.
12-	Customers are being sold unavailable seats in the second round of tickets. Resolved by passing variable "seats" instead of "availSeats".
13-	After moving srand, occasionally customers will be sold unavailable seats when selling the second chance seats. Resolved in iteration 11 by moving srand to main() and adding a
	"hesitancy" variable to Order allowing for one randomised value to be used in the checks if needed.
14-	Seats aren't being updated after secondChanceTickets. Resolved by passing variable "seats" instead of "availSeats".

Iterations:
1 -	I added threads to the original code and experienced problems 1 and 2.
2 -	I added a for loop to remove each of the used threads from the cashiers. This allowed me to remove the if statement to check if the thread
   	was rejoinable. Experienced problem 3
3 - 	Added a function to rejoin the threads and another function to remove the used threads from cashiers.
4 - 	Added a function to check for seat availability if a customers original seat is unavailable. Experienced problem 4.
5 - 	Tried to change code so that threads are passed a workflow where they sell the seat if possible, and then if not look for a new seat.
   	(main creates each thread -> thread checks for seat -> thread sells seat / finds new seat -> thread rejoins)
   	This caused problem 5, which was possibly caused by passing a copy of seats instead of a reference to it. Changing the passed in value to
   	a reference partially solved the problem and caused problem 6.
6 - 	I fixed problem 6 by assigning temp to the order instead of trying to delete and then assign each value. I also experienced issue 7
   	most likely because by the time customer 6 was able to get access to the functions all of the seats were unavailable. I also changed the
   	code to print the customer name and colour each time they print to cout. I also changed the seat changing function to check if enough seats
   	were available before checking if the customer wants to change.
7 - 	I added more locks and unlocks to the first mutex, as the last few iterations felt bottlenecked by the threads waiting for the mutex. I 
   	was able to get the customers to actually feel like they were racing for tickets again, rather than having the program feel as if it were 
   	not multithreaded. Problem 9 popped up, but I was able to resolve that by using a second mutex.
   	I also added a call to the printOrder function to print the customers new tickets when they change seats and slightly modified the function
   	so it will print "new" when the seats have been changed. Also added customer rage and changed how the functions get random ints when needed.
8 - 	Removed mutex from printOrder() and modified removeUsed() to use the size of the vector of orders instead of fixed value (6). Changed where mutex locks and unlocks in sellSeats().
9 - 	Added check for if any seats are available after workflow(), to make sure no seats are available at the end of the program. Also fixed some formatting where lines were not spaced 
   	and appearing messy in output.
10 -	Moved srand to make sure all random numbers actually were random. Experienced issues 11, 12 and 13.
11 -	Changed workflow to no longer check if customer wants to change tickets, and added a second function to perform that task. Added hesitancy to Order(struct) to allow for
   	one consistent value to be used for each random number check. Removed the function to generate a random number each time it is called also.
   	To solve issues 11, 12 and 14, which were originally using two vectors which were created using the remaining seats and remaining orders, I changed the passed in variable (when called in main())
   	to be the original seats and orders, and added a condition to check whether they need to be sold tickets in the second round.