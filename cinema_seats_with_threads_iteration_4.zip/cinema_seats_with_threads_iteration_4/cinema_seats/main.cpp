//////////////////////////////////////////////////////////////////////////////
//
//  CAO107 LAB 2 - Cinema seats
//
//  You run a local cinema in Ultimo. It's become so popular that your 
//  single box office sales person is smashed with orders, and you've 
//  installed 6 new registers, all staffed, to allow up to six
//  customers to buy seats at the same time. Now you can sell six times
//  as many tickets, time to get PAID.
//
//  Are things ever that simple though?
//  
//  THE CODE:
//
//  We have five cinema seats, G1-G5, and six customers. Each customer
//  is represented by the order they'd like to place; some want a single
//  seat, some want three. Some customer's orders can easily block
//  another's: If G1 and G3 are sold, the dude looking for G2 and G3 is out
//  of luck. 
//
//  THE PROGRAM SO FAR: 
// 
//  1. Shows the seats and their availability : green yes, red no.
//  2. Shows the customers waiting
//  3. Handles the orders one by one, in sequence, displaying the outcome
//  4. Displays all completed orders (that were stored in ordersCompleted)
//  5. Shows tickets sold.
//  6. Works great.
//
//  THE READING:
//
//  You will find the answers you seek in the following sections of 
//  'Concurrency in Action', downloadable from the CAO107 resources page
//  on DMDOCS (my notes).
//
//  3.1.1, 3.1.2 Race Conditions (p35) and avoiding them.
//  3.2, 3.2.1 Protecting shared data with mutexes
//  
//  YOUR TASKS
//  1. Deploy your six new staff! That is: change from a single seller 
//     (sellSeats function) to multiple sellers (threads). This is almost
//     identical to our quicksort threading solution.
//  2. Run the program a bunch of times and observe! Do any issues emerge?
//     Does the seat availability chart match up with the orders completed?
//     Check for any problems with allocation: will everyone who was sold
//     tickets be happy? Take a SCREENSHOT of your output whenever you see
//     a problem, and write a clear description of the problem.
//  3. For each problem you've identified:
//     1. What do you think was the cause of this problem? Provide detail
//        beyond "threads did it". How did they cause the problem?
//     2. You're going to keep all six sales people, and customers are going
//        going to still be served in parallel, but small changes to the 
//        process can be made. What changes would you make to solve each problem?
//        Think about this in plain english in terms of how you'd handle the 
//        problem of several people selling from the same pool of products. 
//    3.  Refer to chapter 3 of Concurrency In Action (see THE READING).
//        What parallel programming features does C++ offer that can help us 
//        with these "race condition" problems? How do they help? (In your own
//        words, with short quotes allowed)
//    4.  Write some pseudo code (basically shortened, plain english code 
//        to fix each problem, without having to use the proper syntax
//        of C++. You don't need to show the whole program, just the areas
//        you need real changes. See a pseudocde sample below in TIPS.
//
//        If you're not sure about how to approach pseudocode, here's an 
//        example from sellSeats()
//
//        for each order
//          print out the order in colour
//          if all the seats are available
//            print "SOLD!" 
//            mark the order complete
//            put a copy of it in orders Completed collection
//            mark the seat unavailable
//          otherwise
//              print "unavailable"
//          end if
//        end for
//
//  TIPS: 
//  * Look in `structures.h` to see what makes up a `Seat` or an `Order`.
//  * Colours are defined in `colornames.h`
//
//  PSEUDOCODE 
//
//  If you're not sure about the pseudocode, here's an example of a section
//  of the sellSeats() function.
//
//    for each order
//      print out the order in colour
//      if all the seats are available
//        print "SOLD!" 
//        mark the order complete
//        put a copy of it in orders Completed collection
//        mark the seat unavailable
//      otherwise
//          print "unavailable"
//      end if
//    end for
//
//////////////////////////////////////////////////////////////////////////////

#include <thread>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include "colornames.h"
#include "structures.h"
#include "chrono"
using namespace std;
// Need available movie seats
// Need booking system to attempt to book them
// 5 cashiers can be asked to make bookings
// It returns a result telling you if you succeeded, and what tickets you got.
// Tickets are dispensed to 
vector<Order> ordersCompleted;
mutex outLock;
mutex orderLock;

bool checkSeatChange()
{
  int temp = rand() % 100 + 1;
  if (temp >= 60)
  {
    cout << ": Awesome! I'll take any you can find!\n";
    return true;
  }
  else if (temp < 60 && temp >= 40)
  {
    cout << ": Fine, I'll swap I guess...\n";
    return true;
  }
  else
  {
    cout << ": No thanks! My night is ruined now!\n";
    return false;
  }
}

Order seatAvailability(Order& order, vector<Seat>& seats)
{
  outLock.lock();
  Order temp;
  temp.custName = order.custName;
  temp.color = order.color;
  temp.sold = order.sold;

  if (checkSeatChange())
  {
    for (auto& seat : seats)
    {
      if (seat.available)
      {
        temp.seatIds.push_back(seat.id);
        if (temp.seatIds.size() == order.seatIds.size()) break;
      }
    }
  }

  if (temp.seatIds.size() < order.seatIds.size())
  {
    cout << ": Not enough seats left! D:\n";
  }
  outLock.unlock();
  return temp;
}

bool sellSeats(Order& order, vector<Seat>& seats, int counter)
{
  /*if (counter == 0) */outLock.lock();
  counter++;
  this_thread::sleep_for(500ms);
  cout << white << order.color << order.custName << white << on_black;
  //outLock.unlock();
  // if the seats in the order aren't already sold, mark them sold and return true
  bool allAvailable{ true };
  // Go through the order. If the seat 
  for (auto& seatId : order.seatIds)
  {
    for (auto& seat : seats)
    {
      // If we find the seat and it's not available, order is ded.
      if (seat.id == seatId && !seat.available)
      {
        Order newSeats = seatAvailability(order, seats);
        if (newSeats.seatIds.size() == order.seatIds.size())
        {
            /*outLock.unlock();*/
            if (sellSeats(newSeats, seats, 1))
            {
              allAvailable = false;
              break;
            }
            /*outLock.lock();*/
        }
        
        cout << ": unavailable D:\n";
        allAvailable = false;
        break;
      }
    }
  }
  if (allAvailable)
  {
    cout << ": Sold!\n";
    order.sold = true;
    ordersCompleted.push_back(order);
    // oh boy, we sure wasted some time there before marking the seats
    // unavailable. What could go wrong?
    for (auto& seatId : order.seatIds)
    {
      for (auto& seat : seats)
      {
        if (seat.id == seatId) seat.available = false;
      }
    }
  }
  outLock.unlock();
  return allAvailable;
}

void printOrder(Order& order)
{
  outLock.lock();
  cout << white << order.color << order.custName << white << on_black << ", seats: [";
  for (auto& seatId : order.seatIds)
  {
    cout << seatId << " ";
  }
  cout << "\b]\n";   // backspace removes the space after the last seat id
  outLock.unlock();
}

void showSeats(vector<Seat>& seats)
{
  cout << "\n" << "## Seat Availability" << "\n\n";
  int seatCount = seats.size();
  string line = "-";
  for (auto i = 0; i < seatCount; ++i)
  {
    line += "-----";
  }

  for (auto& seat : seats)
  {
    // If the seat is available, use green background, else red
    // if this syntax looks weird, google "universal initializers" and
    // "c++ ternary operator"
    string bg{ (seat.available) ? on_green : on_red };
    cout << "|" << white << bg << " " << seat.id << " " << white_on_black;
  }
  cout << "|" << endl;
}

void rejoinThreads(vector<thread>& p_Cashiers)
{
    for (thread& cashier : p_Cashiers)
    {
        cashier.join();
    }
}

void removeUsed(vector<thread>& p_Cashiers)
{
    for (int i = 0; i < 6; i++)
    {
        p_Cashiers.pop_back();
    }
}

int main()
{
  vector<thread> cashiers;

  auto orders = vector<Order>{
    { "Cust 1", on_red, {"G1", "G2"}},
    { "Cust 2", on_blue, {"G1"}},
    { "Cust 3", on_green, {"G4", "G5"}},
    { "Cust 4", on_yellow,  {"G5"}}, // potential disruptor here
    { "Cust 5", on_magenta, {"G4"}},
    { "Cust 6", on_cyan,  {"G3", "G4"}}  // Another cheeky one
  };

  auto seats = vector<Seat>{
    { "G1", true },
    { "G2", true },
    { "G3", true },
    { "G4", true },
    { "G5", true },
  };

  showSeats(seats);
  cout << "\n" << "## Customers Enter" << "\n\n";
  for (auto& order : orders)
  {
    cashiers.push_back(thread(printOrder, ref(order)));
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);

  cout << "\n" << "## Sales Begin" << "\n\n";
  for (Order& order : orders)
  {
    cashiers.push_back(thread(sellSeats, ref(order), ref(seats), 0));
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);

  cout << "\n" << "## Successful Orders" << "\n\n";
  for (auto& order : ordersCompleted)
  {
    printOrder(order);
  }

  showSeats(seats);
}
