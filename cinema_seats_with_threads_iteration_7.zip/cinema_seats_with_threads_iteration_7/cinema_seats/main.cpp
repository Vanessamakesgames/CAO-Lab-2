//////////////////////////////////////////////////////////////////////////////
//
//  CAO107 LAB 2 - Cinema seats
//
//  You run a local cinema in Ultimo. It's become so popular that your 
//  single box office sales person is smashed with orders, and you've 
//  installed 6 new registers, all staffed, to allow up to six
//  customers to buy seats at the same time. Now you can sell six times
//  as many tickets, time to get PAID.
//
//  Are things ever that simple though?
//  
//  THE CODE:
//
//  We have five cinema seats, G1-G5, and six customers. Each customer
//  is represented by the order they'd like to place; some want a single
//  seat, some want three. Some customer's orders can easily block
//  another's: If G1 and G3 are sold, the dude looking for G2 and G3 is out
//  of luck. 
//
//  THE PROGRAM SO FAR: 
// 
//  1. Shows the seats and their availability : green yes, red no.
//  2. Shows the customers waiting
//  3. Handles the orders one by one, in sequence, displaying the outcome
//  4. Displays all completed orders (that were stored in ordersCompleted)
//  5. Shows tickets sold.
//  6. Works great.
//
//  THE READING:
//
//  You will find the answers you seek in the following sections of 
//  'Concurrency in Action', downloadable from the CAO107 resources page
//  on DMDOCS (my notes).
//
//  3.1.1, 3.1.2 Race Conditions (p35) and avoiding them.
//  3.2, 3.2.1 Protecting shared data with mutexes
//  
//  YOUR TASKS
//  1. Deploy your six new staff! That is: change from a single seller 
//     (sellSeats function) to multiple sellers (threads). This is almost
//     identical to our quicksort threading solution.
//  2. Run the program a bunch of times and observe! Do any issues emerge?
//     Does the seat availability chart match up with the orders completed?
//     Check for any problems with allocation: will everyone who was sold
//     tickets be happy? Take a SCREENSHOT of your output whenever you see
//     a problem, and write a clear description of the problem.
//  3. For each problem you've identified:
//     1. What do you think was the cause of this problem? Provide detail
//        beyond "threads did it". How did they cause the problem?
//     2. You're going to keep all six sales people, and customers are going
//        going to still be served in parallel, but small changes to the 
//        process can be made. What changes would you make to solve each problem?
//        Think about this in plain english in terms of how you'd handle the 
//        problem of several people selling from the same pool of products. 
//    3.  Refer to chapter 3 of Concurrency In Action (see THE READING).
//        What parallel programming features does C++ offer that can help us 
//        with these "race condition" problems? How do they help? (In your own
//        words, with short quotes allowed)
//    4.  Write some pseudo code (basically shortened, plain english code 
//        to fix each problem, without having to use the proper syntax
//        of C++. You don't need to show the whole program, just the areas
//        you need real changes. See a pseudocde sample below in TIPS.
//
//        If you're not sure about how to approach pseudocode, here's an 
//        example from sellSeats()
//
//        for each order
//          print out the order in colour
//          if all the seats are available
//            print "SOLD!" 
//            mark the order complete
//            put a copy of it in orders Completed collection
//            mark the seat unavailable
//          otherwise
//              print "unavailable"
//          end if
//        end for
//
//  TIPS: 
//  * Look in `structures.h` to see what makes up a `Seat` or an `Order`.
//  * Colours are defined in `colornames.h`
//
//  PSEUDOCODE 
//
//  If you're not sure about the pseudocode, here's an example of a section
//  of the sellSeats() function.
//
//    for each order
//      print out the order in colour
//      if all the seats are available
//        print "SOLD!" 
//        mark the order complete
//        put a copy of it in orders Completed collection
//        mark the seat unavailable
//      otherwise
//          print "unavailable"
//      end if
//    end for
//
//////////////////////////////////////////////////////////////////////////////

#include <thread>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include "colornames.h"
#include "structures.h"
#include "chrono"
#include "time.h"
using namespace std;
// Need available movie seats
// Need booking system to attempt to book them
// 5 cashiers can be asked to make bookings
// It returns a result telling you if you succeeded, and what tickets you got.
// Tickets are dispensed to 
vector<Order> ordersCompleted;
mutex outLock;
mutex orderLock;

// print the customers name with the color of their order
void printCustName(Order& order)
{
    cout << white << order.color << order.custName << white << on_black;
}

int getRandomNumber()
{
  srand(time(NULL));
  int temp = rand() % 100 + 1;
  return temp;
}

// check if customer wants to change seats
bool checkSeatChange()
{
  int temp = getRandomNumber();
  if (temp >= 60)
  {
    cout << ": Awesome! I'll take any you can find!\n";
    return true;
  }
  else if (temp < 60 && temp >= 40)
  {
    cout << ": Fine, I'll swap I guess...\n";
    return true;
  }
  else
  {
    cout << ": No thanks! My night is ruined now!\n";
    return false;
  }
}

bool checkAvailability(Order& order, vector<Seat>& seats)
{
  int availSeats{0};
  for (auto& seat : seats)
  {
    if (seat.available) availSeats++;
  }
  if (availSeats >= order.seatIds.size()) return true;
  return false;
}

// checks if there are seats the customer can change to, then if the customer wants to. this returns the customers new order.
Order seatChange(Order& order, vector<Seat>& seats)
{
  /*outLock.lock();*/
  Order temp;
  temp.custName = order.custName;
  temp.color = order.color;
  temp.sold = order.sold;
  if (checkAvailability(order, seats))
  {
    orderLock.lock();
    printCustName(order);
    if (checkSeatChange())
    {
      for (auto& seat : seats)
      {
        if (seat.available)
        {
          temp.seatIds.push_back(seat.id);
          if (temp.seatIds.size() == order.seatIds.size()) break; // if seats in temp is equal to seats needed break out of loop
        }
      }
    }
    orderLock.unlock();
  }
  else
  {
    orderLock.lock();
    printCustName(order);
    cout << ": Not enough seats left! D:\n";
    orderLock.unlock();
  }
  
  /*outLock.unlock();*/
  return temp;
}

// sells seats to the customer
bool sellSeats(Order& order, vector<Seat>& seats)
{
  orderLock.lock();
  printCustName(order);
  //outLock.unlock();
  // if the seats in the order aren't already sold, mark them sold and return true
  bool allAvailable{ true };

  for (auto& seatId : order.seatIds)
  {
    for (auto& seat : seats)
    {
      // If we find the seat and it's not available, order is ded.
      if (seat.id == seatId && !seat.available)
      {        
        cout << ": unavailable D:\n";
        allAvailable = false;
        break;
      }
    }
    if (!allAvailable) break; // If customer wants two tickets and first seat is unavailable this exits the loop
  }
  if (allAvailable)
  {
    cout << ": Sold!\n";
    order.sold = true;
    ordersCompleted.push_back(order);

    for (auto& seatId : order.seatIds)
    {
      for (auto& seat : seats)
      {
        if (seat.id == seatId) seat.available = false;
      }
    }
  }
  orderLock.unlock();
  return allAvailable;
}

// prints the customer/successful orders
void printOrder(Order& order, bool isItNew)
{
  orderLock.lock();
  printCustName(order);
  if (!isItNew) cout << ", seats: [";
  else cout << ", new seats: [";
  for (auto& seatId : order.seatIds)
  {
    cout << seatId << " ";
  }
  cout << "\b]\n";   // backspace removes the space after the last seat id
  orderLock.unlock();
}

// shows the available and unavailable seats
void showSeats(vector<Seat>& seats)
{
  cout << "\n" << "## Seat Availability" << "\n\n";
  int seatCount = seats.size();
  string line = "-";
  for (auto i = 0; i < seatCount; ++i)
  {
    line += "-----";
  }

  for (auto& seat : seats)
  {
    // If the seat is available, use green background, else red
    // if this syntax looks weird, google "universal initializers" and
    // "c++ ternary operator"
    string bg{ (seat.available) ? on_green : on_red };
    cout << "|" << white << bg << " " << seat.id << " " << white_on_black;
  }
  cout << "|" << endl;
}

// get rid of this and just put back into main
void rejoinThreads(vector<thread>& p_Cashiers)
{
  for (thread& cashier : p_Cashiers)
  {
    if (cashier.joinable()) cashier.join();
  }
}

// get rid of this too
void removeUsed(vector<thread>& p_Cashiers)
{
    for (int i = 0; i < 6; i++)
    {
        p_Cashiers.pop_back();
    }
}

// cashier sells seats if possible, then changes seats (if possible) if the original seats were unavailable
void workflow(Order& order, vector<Seat>& seats)
{
    outLock.lock();
    this_thread::sleep_for(500ms);
    
    printOrder(order, false);
    outLock.unlock();
    if (!sellSeats(order, seats)) // If the seats are unavailable
    {
        outLock.lock();
        Order temp;
        temp = seatChange(order, seats); // Need to find if any other seats are available
        if (order.seatIds.size() == temp.seatIds.size())
        {
            order = temp;
            printOrder(order, true);
            sellSeats(order, seats);
        }
    }
    else outLock.lock();
    outLock.unlock();
}

// the angry customers that missed out
void customerRage(Order& angryCustomer)
{
  outLock.lock();
  this_thread::sleep_for(500ms);
  int rageMeter = getRandomNumber();
  printCustName(angryCustomer);
  if (rageMeter >= 80)
  {
    cout << ": *throws a cashier through the popcorn machine*\n";
    outLock.unlock();
  }
  else if (rageMeter >= 60 && rageMeter < 80)
  {
    cout << ": That can't be! I demand to speak to your manager!\n";
    outLock.unlock();
  }
  else if (rageMeter >= 40 && rageMeter < 60)
  {
    cout << ": Well you've lost me as a customer! Good Day!\n";
    outLock.unlock();
  }
  else if (rageMeter >= 20 && rageMeter < 40)
  {
    cout << ": Arghhhhhh! But I have to see the new Marvel movie!\n";
    outLock.unlock();
  }
  else
  {
    cout << ": Damn, I'll go play video games instead\n";
    outLock.unlock();
  }
}

int main()
{
  vector<thread> cashiers;

  auto orders = vector<Order>{
    { "Cust 1", on_red, {"G1", "G2"}},
    { "Cust 2", on_blue, {"G1"}},
    { "Cust 3", on_green, {"G4", "G5"}},
    { "Cust 4", on_yellow,  {"G5"}}, // potential disruptor here
    { "Cust 5", on_magenta, {"G4"}},
    { "Cust 6", on_cyan,  {"G3", "G4"}}  // Another cheeky one
  };

  auto seats = vector<Seat>{
    { "G1", true },
    { "G2", true },
    { "G3", true },
    { "G4", true },
    { "G5", true },
  };
  cout << "\n" << "## Tonights available seats" << "\n\n";
  showSeats(seats);

  cout << "\n" << "## Customers Enter and the races are on!" << "\n\n";
  for (auto& order : orders)
  {
    cashiers.push_back(thread(workflow, ref(order), ref(seats)));
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);

  cout << "\n" << "## Successful Orders" << "\n\n";
  for (auto& order : ordersCompleted)
  {
    printOrder(order, false);
  }

  showSeats(seats);

  vector<Order> angryCustomers;
  for (auto& order : orders)
  {
    if (!order.sold) angryCustomers.push_back(order);
  }

  for (auto& rage : angryCustomers)
  {
    cashiers.push_back(thread(customerRage, ref(rage)));
  }

  rejoinThreads(cashiers);
  removeUsed(cashiers);
  
  cout << "Boss, we need more seats!\n";
}
